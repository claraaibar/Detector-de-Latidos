function [sensibilidad, VPP] = detector_latidos_y_rendimiento(senal_ecg, anotacion, Fs)
%ENTREGA
% ____________________________________________________________________________

%PARTE 1 
%DETECCIÓN DE LATIDOS + DE SU COMIENZO Y FINAL
%Creamos filtros de paso bajo y alto

%Filtrado

%FPB de butterworth con una Fc de 25 Hz, orden 6
%Originalmente era de 15 Hz, pero la amplitud de los ECGs es muy baja y no superaban el umbral
%Hay que dejar pasar más frecuencias
Fc_pb = 25;
Fs_2 = Fs/2;
wc_pb = Fc_pb/Fs_2;

[B2,A2] = butter(6,wc_pb);

%FPA de butterworth con una Fc de 25 Hz, orden 6
Fc_pa = 5;
wc_pa = Fc_pa/Fs_2;

[B1,A1] = butter(6,wc_pa,'high');

%Filtramos con FPB
filtrado_pb = filtfilt(B1,A1,senal_ecg);

%Filtramos con FPA la señal ya filtrada con FPB
filtrado_pb_pa = filtfilt(B2,A2,filtrado_pb);

%Derivamos
derivada_filtrada = diff(filtrado_pb_pa);

%Elevar al cuadrado para obtener solo picos positivos

derivada_cuadrado_filtrada = derivada_filtrada.^2;

%Aplicar ventana integradora: eliminar dobles picos

vit = 0.150 * Fs;

vit=round(vit);

b=[1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1];

a=vit;

derivada_vent_int = filtfilt(b,a,derivada_cuadrado_filtrada);

%Normalizar señal para que tenga ampitud máxima de 1 NORMALIZAR RESPECTO
%MEDIA

derivada_vent_int_norm = derivada_vent_int/max(derivada_vent_int);

%UNOS Y CEROS SEGÚN ESTÉ EL VALOR DE LA SEÑAL EN EL UMBRAL O NO

%umbral fijo, no se adapta
%El 0.5 es el valor que mejores resultados ha dado
umbral = 0.5;

%Duplicamos la señal procesada
senal_umbral = derivada_vent_int_norm;

%"Digitalización" de la señal: únicamente valores de 1s y 0s
%Se recorre la señal 
for i= 1:length(senal_umbral)

    %Si el valor de la iteración de la señal está por debajo del umbral, toma el valor 0
    if senal_umbral(i) < umbral
        senal_umbral(i) = 0;
    end
    
    %Si el valor de la iteración de la señal está por encima del umbral, toma el valor 1
    if senal_umbral(i) > umbral
        senal_umbral(i) = 1;
 
    end
   
end


%Detección del inicio y final de los pulsos sobre la señal umbral

inicio_pulsos = [];

final_pulsos = [];

%Bucle for para recorrer la señal umbral
%como voy a comparar valores, empiezo en la muestra 2 de la señal
for i= 2:(length(senal_umbral)-1)

 %Si la muestra es 1 y la anterior es un 0, acaba de comenzar el latido

if senal_umbral(i) == 1  && senal_umbral(i-1) == 0

    %Añado número de la muestra en la que comienza el latido al vector

    inicio_pulsos(end+1) = i;

end

%Si la muestra es 0 y la anterior es un 1, acaba de terminar el latido

if senal_umbral(i) == 0  && senal_umbral(i-1) == 1

    %Añado número de la muestra en la que termina el latido al vector

 final_pulsos (end+1) = i;

end
end

eje_x = linspace(0,length(senal_ecg),length(senal_ecg));



%CALCULAR MUESTRA EN LA QUE SE DA EL PULSO (punto intermedio entre su
%inicio y final)

pulsos = [];

%Bucle for para recorrer el vector de las muestras de inicio pulsos 
%Se podría hacer también con el vector de final pulsos, es lo mismo porque
%tienen la misma longitud

for i = 1:length(inicio_pulsos)

    %Por cada muestra (que corresponde a un latido) genero un valor intermedio entre el comienzo y el final
    %del pulso: el centro del latido aprox

pulsos(end+1)=(inicio_pulsos(i)+final_pulsos(i))/2;

end

pulsos = round(pulsos, 0);

%Ploteamos resultado final sobre la señal del ECG
%Se marcan los sus inicios y finales de los pulsos

%Inicio y final pulsos
plot(eje_x,senal_ecg,'-p','MarkerIndices',[final_pulsos inicio_pulsos],...
    'MarkerFaceColor','red',...
    'MarkerSize',10),

hold on,

% Se marcan los latidos en el ECG

plot(eje_x,senal_ecg,'-p','MarkerIndices',pulsos,...
    'MarkerFaceColor','blue',...
    'MarkerSize',10);
%____________________________________________________________________________

%PARTE 2

%Calcular rendimiento del algoritmo: sensibilidad y VPP

sensibilidad = [];

VPP = [];

falsos_positivos = [];

falsos_negativos = [];

verdaderos_positivos = [];

%Recorremos pulsos calculados
longitud = length(pulsos);

for i= 1:longitud 

    %Marcamos el límite inferior y superior de los pulsos del algoritmo
    %No puede haber una diferencia mayor a 120 ms, traducido a 21 muestras
    %con Fs de 360
    limite_inferior = pulsos(i) - 21;
    limite_superior = pulsos(i) + 21;

%Detección: si la muestra de la anotación se encuentra en el umbral de un
%latido detectado por el algoritmo, se almacena en deteccion 
deteccion = anotacion(anotacion>limite_inferior);
deteccion = deteccion(deteccion<limite_superior);

if isempty(deteccion)

    %Si no se ha almacenado valor en detección es que el latido detectado
    %por el algoritmo en realidad no se da (FP)
    falsos_positivos = [falsos_positivos deteccion];

else 

    %Si  se ha almacenado valor en detección es que el latido detectado
    %por el algoritmo existe de verdad(VP)
    verdaderos_positivos =[verdaderos_positivos deteccion];

end
end

%Recorremos anotación: mismo proceso pero a la inversa

longitud = length(anotacion);

for i= 1:longitud 

    %Marcamos el límite inferior y superior de los pulsos de las
    %anotaciones
    %No puede haber una diferencia mayor a 120 ms, traducido a 21 muestras
    %con Fs de 360
    limite_inferior = anotacion(i) - 21;
    limite_superior = anotacion(i) + 21;

%Detección: si la muestra de la anotación se encuentra en el umbral de un
%latido detectado por el algoritmo, se almacena en deteccion 
deteccion = pulsos(pulsos>limite_inferior);
deteccion = deteccion(deteccion<limite_superior);

if isempty(deteccion)

    %Si  se ha almacenado valor en detección es que el latido detectado
    %por el algoritmo existe de verdad(VP)
    falsos_negativos = [falsos_negativos anotacion(i)];

end
end

%Calculamos e imprimimos el valor de sensibilidad con los VP y FN
%detectados
sensibilidad = length(verdaderos_positivos)/(length(verdaderos_positivos)+length(falsos_negativos));sensibilidad

%Calculamos e imprimimos el valor predictivo postivio con los VP y FP
%detectados
VPP = length(verdaderos_positivos)/(length(verdaderos_positivos)+length(falsos_positivos));VPP

end