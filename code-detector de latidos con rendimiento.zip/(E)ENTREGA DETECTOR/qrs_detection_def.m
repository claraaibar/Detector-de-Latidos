%__________________________________________________________________________

%PRÁCTICA 3: DETECTOR DE LATIDOS. Clara Aibar
%ENTREGA

%__________________________________________________________________________
%OBJETIVOS:

%Aplicar método de detección de onda QRS de Tompkins 

%Visualizar los cambios que toma la señal durante su filtrado y
%procesamiento

%Crear algoritmo que encentre y guarde de forma efectiva los puntos de
%inicio y fin del complejo QRS  

%__________________________________________________________________________

%PASO 1: CARGAR SEÑALES ECG

%OBJETIVO: tener señales de 10 ECGs distintos con complejo PQRST visible
%Con al menos 1 minuto de duración 
%Importante conocer su Fs
%Formato .mat

%Se declaran las variables necesarias para la descarga de las señales
Fs = 360;
inim = 255000;
finim = 255000 + 21601;

%Descargar y almacenar 10 señales junto a sus anotaciones N
[senal1,Fs,tm]=rdsamp('mitdb/123',[],finim,inim);
ann_1 = rdann('mitdb/123', 'atr', [],finim,inim,'N')- 255000;

[senal2,Fs,tm]=rdsamp('mitdb/113',[],finim,inim);
ann_2 = rdann('mitdb/113', 'atr', [],finim,inim,'N')- 255000;

[senal3,Fs,tm]=rdsamp('mitdb/234',[],finim,inim);
ann_3 = rdann('mitdb/234', 'atr', [],finim,inim,'N')- 255000;

[senal4,Fs,tm]=rdsamp('mitdb/231',[],finim,inim);
ann_4 = rdann('mitdb/231', 'atr', [],finim,inim,'N')- 255000;

[senal5,Fs,tm]=rdsamp('mitdb/230',[],finim,inim);
ann_5 = rdann('mitdb/230', 'atr', [],finim,inim,'N')- 255000;

[senal6,Fs,tm]=rdsamp('mitdb/221',[],finim,inim);
ann_6 = rdann('mitdb/221', 'atr', [],finim,inim,'N')- 255000;

[senal7,Fs,tm]=rdsamp('mitdb/108',[],finim,inim);
ann_7 = rdann('mitdb/108', 'atr', [],finim,inim,'N')- 255000;

[senal8,Fs,tm]=rdsamp('mitdb/115',[],finim,inim);
ann_8 = rdann('mitdb/115', 'atr', [],finim,inim,'N')- 255000;

[senal9,Fs,tm]=rdsamp('mitdb/116',[],finim,inim);
ann_9 = rdann('mitdb/116', 'atr', [],finim,inim,'N')- 255000;

[senal10,Fs,tm]=rdsamp('mitdb/234',[],finim,inim);
ann_10 = rdann('mitdb/234', 'atr', [],finim,inim,'N')- 255000;

%Nos quedamos con un solo canal en todas las señales
senal_1=senal1(:,1);
senal_2=senal2(:,1);
senal_3=senal3(:,1);
senal_4=senal4(:,1);
senal_5=senal5(:,1);
senal_6=senal6(:,1);
senal_7=senal7(:,1);
senal_8=senal8(:,1);
senal_9=senal9(:,1);
senal_10=senal10(:,1);

%Aquí aplicamos la función para la detección de latidos y cálculo del
%rendimiento del algoritmo

% Perfecto!!
[sensibilidad, VPP] = detector_latidos_y_rendimiento(senal_1,ann_1, Fs);

% Perfecto!!
[sensibilidad, VPP] = detector_latidos_y_rendimiento(senal_2,ann_2, Fs);

% Perfecto!!
[sensibilidad, VPP] = detector_latidos_y_rendimiento(senal_3,ann_3, Fs);

% Perfecto!!
[sensibilidad, VPP] = detector_latidos_y_rendimiento(senal_4,ann_4, Fs);

% Perfecto!!
[sensibilidad, VPP] = detector_latidos_y_rendimiento(senal_5,ann_5, Fs);

% Casi perfecto!!
[sensibilidad, VPP] = detector_latidos_y_rendimiento(senal_6,ann_6, Fs);

% Casi perfecto!!
[sensibilidad, VPP] = detector_latidos_y_rendimiento(senal_7,ann_7, Fs);

% Perfecto!!
[sensibilidad, VPP] = detector_latidos_y_rendimiento(senal_8,ann_8, Fs);

% Perfecto!!
[sensibilidad, VPP] = detector_latidos_y_rendimiento(senal_9,ann_9, Fs);

% Perfecto!!
[sensibilidad, VPP] = detector_latidos_y_rendimiento(senal_10,ann_10, Fs);

%A continuación, explicamos los pasos seguidos en la función detalladamente

%__________________________________________________________________________

%PASO 2: PRE-PROCESAMIENTO DE LA SEÑAL
%Visualizar la señal en tiempo y frecuencia 

%Señal representada en el dominio del tiempo
eje_senal_1=linspace(0,length(senal_1),length(senal_1));
plot(eje_senal_1,senal_1),title("ECG representado en el dominio del tiempo");

%Señal representada en el dominio de la frecuencia
tf_senal_1= fftshift(fft(senal_1));
eje_f_ecg=linspace(-Fs/2,Fs/2,length(tf_senal_1));
plot(eje_f_ecg,abs(tf_senal_1 /length(tf_senal_1))),title("ECG representado en el dominio de la frecuencia");

%__________________________________________________________________________

%PASO 3: Filtrado de artefactos en la señal ECG

%Complejo QRS se encuentra entre 5 Hz y 15 Hz: filtrar el resto
%Filtrar con función filtfilt() para evitar desfase

%FPA con Fc de 5 Hz 

%FPB de butterworth con una Fc de 25 Hz, orden 6
%Originalmente era de 15 Hz, pero la amplitud de los ECGs es muy baja y no superaban el umbral
%Hay que dejar pasar más frecuencias
Fc_pb = 25;
Fs_2 = Fs/2;
wc_pb = Fc_pb/Fs_2;

[B2,A2] = butter(6,wc_pb);

%Función que devuelve respuesta en frecuencia de sistema con coeficientes
[a2,b2]=freqz(B2,A2);

%Le metemos una delta al sistema: obtenemos respuesta al impulso
%y1 = filter(B1,A1,delta);
%stem(y1);

%FPA de butterworth con una Fc de 25 Hz, orden 6
Fc_pa = 5;
wc_pa = Fc_pa/Fs_2;

[B1,A1] = butter(6,wc_pa,'high');

%Función que devuelve respuesta en frecuencia de sistema con coeficientes
[a1,b1]=freqz(B1,A1);

freqz(B1,A1);

%Le metemos una delta al sistema: obtenemos respuesta al impulso
%y2 = filter(B2,A2,delta);
%stem(y2);

%Filtrar ECG con FPB
filtrado_ecg_pb = filtfilt(B2,A2,senal_1);

%Diferencias en la señal en el tiempo tras FPB (en subplot para apreciar
%bien las diferencias, superpestas no se ven bien)
subplot(211),plot(eje_senal_1,filtrado_ecg_pb,'r'),title("Señal ECG en el tiempo filtrada PB") ,hold on,
subplot(212),plot(eje_senal_1,senal_1,'b'),title("Señal ECG en el tiempo original");

%Observar cambios en frecuencia tras FPB
tf_filtrado_ecg_pb= fftshift(fft(filtrado_ecg_pb));
eje_tf_fpb=linspace(-Fs/2,Fs/2,length(tf_filtrado_ecg_pb));

subplot(211),plot(eje_tf_fpb,abs(tf_filtrado_ecg_pb /length(tf_filtrado_ecg_pb))),title("Señaal ECG en frecuencia tras FPB"),
subplot(212),plot(eje_f_ecg,abs(tf_senal_1 /length(tf_senal_1))),title("Señal ECG en frecuencia sin filtrar ");


%Filtrar ECG filtado previamente con un FPB con FPA
filtrado_ecg_pbypa = filtfilt(B1,A1,filtrado_ecg_pb);

%Diferencias en la señal en el tiempo tras FPB y FPA
subplot(211),plot(eje_senal_1,filtrado_ecg_pbypa,'r'),title("Señal ECG en el tiempo filtrada PB y PA"), hold on,
subplot(212),plot(eje_senal_1,senal_1,'b'),title("Señal ECG en el tiempo original");

%Observar cambios en frecuecia tras FPB y FPA 
tf_filtrado_ecg_pbypa= fftshift(fft(filtrado_ecg_pbypa));
eje_tf_fpbypa=linspace(-Fs/2,Fs/2,length(tf_filtrado_ecg_pbypa));

subplot(211),plot(eje_tf_fpb,abs(tf_filtrado_ecg_pbypa /length(tf_filtrado_ecg_pbypa))),title("Señal ECG en frecuencia tras FPA y FPB"),
subplot(212),plot(eje_f_ecg,abs(tf_senal_1 /length(tf_senal_1))),title("Señal ECG en frecuencia sin filtrar ");

%Normalizar señal. Amplitud igual a 1
%NO HACE FALTA AQUÍ, SE HACE AL FINAL ANTES DE APLICAR EL UMBRAL 
% max1 = max(filtrado_ecg_pbypa);
% norm_filtrado_ecg_pbypa=filtrado_ecg_pbypa/max1;
% 
% subplot(211),plot(eje_senal_1,filtrado_ecg_pbypa,'r'),title("Señal ECG filtrada PB y PA") ,
% subplot(212),plot(eje_senal_1,norm_filtrado_ecg_pbypa,'r'),title("Señal ECG filtrada y normalizada");

%__________________________________________________________________________

%PASO 4: DERIVACIÓN (+ELEVACIÓN AL CUADRADO + VENTANA INTEGRADORA)

%Derivar
%Función de derivar de matlab
derivada_filtrada = diff(filtrado_ecg_pbypa);

eje_derivada=linspace(0,length(derivada_filtrada),length(derivada_filtrada));

%Observamos cambio en el dominio del tiempo tras la derivación
subplot(211),plot(eje_derivada,derivada_filtrada,'r'),title("Señal ECG derivada"),hold on,
subplot(212),plot(eje_senal_1,senal_1,'b'),title("Señal ECG únicamente filtrada");

%Elevar al cuadrado para obtener únicamente picos positivos

derivada_cuadrado_filtrada = derivada_filtrada.^2;

subplot(211),plot(eje_derivada,derivada_cuadrado_filtrada,'r'), title ("Señal elevada al cuadrado y derivada"),hold on,
subplot(212),plot(eje_senal_1,senal_1,'b'),title("Señal ECG únicamente filtrada");

%Aplicar ventana integradora: eliminar dobles picos

vit = 0.150 * Fs;

vit=round(vit);

bvi=[1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1];

avi=vit;

derivada_vent_int = filtfilt(bvi,avi,derivada_cuadrado_filtrada);

%plot(eje_derivada,derivada_vent_int,'r');

derivada_vent_int_norm = derivada_vent_int/max(derivada_vent_int);

subplot(211),plot(eje_derivada,derivada_vent_int_norm,'r'), title("Señal con ventana integradora y normalizada"),
subplot(212),plot(eje_derivada,derivada_cuadrado_filtrada,'b'), title ("Señal únicamente elevada al cuadrado");

%__________________________________________________________________________

%PASO 5: DETECTAR QRS Y FILTRARLOS

%AQUÍ EMPIEZA MI ALGORITMO

%TRANSFORMAR SEÑAL A SEÑAL DE UNOS Y CEROS 

%Marco el umbral en 0.5, he ido mirando con cuál tenía mejores resultados
%Como las señales tienen poca amplitud se ha disminuido el umbral hasta 0.5

umbral = 0.5;

%Duplico la señal previemente procesada y fitrada para trabajar con ella
%Podría usar la de antes, pero es para que no se me estropee

senal_umbral = derivada_vent_int_norm;

%Bucle for para recorrer cada muestra de la señal

for i= 1:length(senal_umbral)

    %Si la muestra tiene un valor inferior a nuestro umbral, se le asigna
    %el valor 0

    if senal_umbral(i) < umbral
        senal_umbral(i) = 0;
    end
    
    %Si la muestra tiene un valor superior a nuestro umbral, se le asigna
    %el valor 1

    if senal_umbral(i) > umbral
        senal_umbral(i) = 1;
 
    end
   
end


eje_senal_umbral=linspace(0,length(senal_umbral),length(senal_umbral));

eje_senal_intnorm=linspace(0,length(derivada_vent_int_norm),length(derivada_vent_int_norm));

subplot(211), plot(eje_senal_umbral,senal_umbral,'r'), title("Señal con umbral, 1s y 0s"), hold on,

subplot(212), plot(eje_senal_intnorm,derivada_vent_int_norm), title("Señal procesada y normalizada");


%CALCULAR INICIO Y FINAL DE CADA PULSO

%Declaro vectores vacíos para almacenar valores de muestras de inicio y final de
%los pulsos

inicio_pulso = [];

final_pulso = [];

%Bucle for para recorrer la señal
%como voy a comparar valores, empiezo en la muestra 2

for i= 2:(length(senal_umbral)-1)

    %Si la muestra es 1 y la anterior es un 0, acaba de comenzar el latido

if senal_umbral(i) == 1  && senal_umbral(i-1) == 0

    %Añado número de la muestra en la que comienza el latido al vector

    inicio_pulso(end+1) = i;
end

%Si la muestra es 0 y la anterior es un 1, acaba de terminar el latido

if senal_umbral(i) == 0  && senal_umbral(i-1) == 1

     %Añado número de la muestra en la que termina el latido al vector

    final_pulso(end+1) = i;
end

end

%CALCULAR MUESTRA EN LA QUE SE DA EL PULSO (punto intermedio entre su
%inicio y final)

%Declaro vector vacío que almacene las muestras de los pulsos
pulso = [];

%Bucle for para recorrer el vector de las muestras de inicio pulsos 
%Se podría hacer también con el vector de final pulsos, es lo mismo porque
%tienen la misma longitud

for i = 1:length(inicio_pulso)

    %Por cada muestra (que corresponde a un latido) genero un valor intermedio entre el comienzo y el final
    %del pulso: el centro del latido aprox

    pulso(end+1)=(inicio_pulso(i)+final_pulso(i))/2;

end

pulso = round(pulso, 0);

%Ploteamos resultado final

eje_x = linspace(0,length(senal_1),length(senal_1));

%Inicio y final pulsos
plot(eje_x,senal_1,'-p','MarkerIndices',[final_pulso ...
    inicio_pulso],...
    'MarkerFaceColor','red',...
    'MarkerSize',10),

hold on,

%Latidos

plot(eje_x,senal_1,'-p','MarkerIndices',pulso,...
    'MarkerFaceColor','blue',...
    'MarkerSize',10);

%__________________________________________________________________________
%Calcular rendimeinto del algoritmo

sensibilidad = [];

VPP = [];

falsos_positivos = [];

falsos_negativos = [];

verdaderos_positivos = [];

%Recorremos pulsos calculados
longitud = length(pulso);

for i= 1:longitud 

    limite_inferior = pulso(i) - 21;
    limite_superior = pulso(i) + 21;

%Detección: 
deteccion = ann_1(ann_1>limite_inferior);
deteccion = deteccion(deteccion<limite_superior);

if isempty(deteccion)

    falsos_positivos = [falsos_positivos deteccion];

else 

verdaderos_positivos =[verdaderos_positivos deteccion];

end
end

%Recorremos anotación

longitud = length(ann_1);

for i= 1:longitud 

    limite_inferior = ann_1(i) - 21;
    limite_superior = ann_1(i) + 21;

%Detección: 
deteccion = pulso(pulso>limite_inferior);
deteccion = deteccion(deteccion<limite_superior);

if isempty(deteccion)

    falsos_negativos = [falsos_negativos ann_1(i)];

end
end

sensibilidad = length(verdaderos_positivos)/(length(verdaderos_positivos)+length(falsos_negativos));sensibilidad

VPP = length(verdaderos_positivos)/(length(verdaderos_positivos)+length(falsos_positivos));VPP


